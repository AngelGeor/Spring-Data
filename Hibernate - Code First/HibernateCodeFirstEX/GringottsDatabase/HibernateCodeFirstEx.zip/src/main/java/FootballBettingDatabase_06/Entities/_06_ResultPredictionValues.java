package FootballBettingDatabase_06.Entities;

public enum _06_ResultPredictionValues {
    HOME_TEAM_WIN,
    DRAW_GAME,
    AWAY_TEAM_WIN
}