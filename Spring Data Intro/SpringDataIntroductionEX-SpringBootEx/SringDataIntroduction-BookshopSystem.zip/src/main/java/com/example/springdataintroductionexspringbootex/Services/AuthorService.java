package com.example.springdataintroductionexspringbootex.Services;

import com.example.springdataintroductionexspringbootex.Entities.Author;

public interface AuthorService {

    Author getRandomAuthor();
}
