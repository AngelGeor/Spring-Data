package com.example.springdataintroductionexspringbootex.Entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
