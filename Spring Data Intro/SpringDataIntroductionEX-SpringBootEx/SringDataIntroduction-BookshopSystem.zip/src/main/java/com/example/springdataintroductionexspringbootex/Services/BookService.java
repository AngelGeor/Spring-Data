package com.example.springdataintroductionexspringbootex.Services;

public class BookService {
}
