package com.example.springdataintroductionexspringbootex.Entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
